﻿
1. Structure
```
{"head": {
	"param_0": value,
	"param_1": value,
	...
	},
 "body": content
}\0x01\0x01
```
There is no difference to normal JSON, except two `0x01` bytes at the end of message.

2. There are no other constrains
